import cpp
import semmle.code.cpp.controlflow.ControlFlowGraph

predicate isStmt1(IfStmt ifs1) {
  exists(NotExpr ne1, FunctionCall fc1, EnumConstantAccess ea1 |
    ne1 = ifs1.getCondition().getUnconverted() and
    fc1 = ne1.getOperand().getUnconverted() and
    fc1.getTarget().hasName("CurrentlyOn") and
    ea1 = fc1.getArgument(0).getUnconverted() and
    ea1.getTarget().hasName("IO")
  )
}

predicate isStmtNode1(ControlFlowNode cfn1) {
  exists(IfStmt stmt1 | isStmt1(stmt1) and cfn1 = stmt1)
}

predicate isStmt2(ExprStmt es1, Variable v1) {
  exists(FunctionCall fc2, VariableAccess va_arg2 |
    fc2 = es1.getExpr().getUnconverted() and
    fc2.getTarget().hasName("StopScreenCapture") and
    fc2.getArgument(0).getUnconverted() = v1.getAnAccess() and
    (
      exists(FunctionCall fc1 |
        fc1 = fc2.getQualifier().getUnconverted() and
        fc1.getTarget().hasName("AsVideoCaptureManagerExt")
      )
    )
  )
}

predicate isStmtNode2(ControlFlowNode cfn1, Variable v1) {
  exists(ExprStmt stmt1 | isStmt2(stmt1, v1) and cfn1 = stmt1)
}

from ControlFlowNode cfn, Variable v1
where
  isStmtNode2(cfn, v1) and
  not exists(ControlFlowNode cfn1 |
    isStmtNode1(cfn1) and
    cfn1.getASuccessor+() = cfn
  ) and
  v1.getType().toString() = "const string &"
select cfn, "Match DSL"