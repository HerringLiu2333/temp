import cpp
import semmle.code.cpp.controlflow.ControlFlowGraph

predicate isStmt1(IfStmt ifs1) {
  exists(NotExpr ne1, FunctionCall fc1, EnumConstantAccess ea1 |
    ne1 = ifs1.getCondition().getUnconverted() and
    fc1 = ne1.getOperand().getUnconverted() and
    fc1.getTarget().hasName("CurrentlyOn") and
    ea1 = fc1.getArgument(0).getUnconverted() and
    ea1.getTarget().hasName("IO")
  )
}

predicate isStmtNode1(ControlFlowNode cfn1) {
  exists(IfStmt stmt1 | isStmt1(stmt1) and cfn1 = stmt1)
}

predicate isStmt2(ExprStmt es1) {
  exists(FunctionCall fc2 |
    fc2 = es1.getExpr().getUnconverted() and
    fc2.getTarget().hasName("SetScreenCapturePickerShow") and
    (
      exists(FunctionCall fc1 |
        fc1 = fc2.getQualifier().getUnconverted() and
        fc1.getTarget().hasName("AsVideoCaptureManagerExt")
      )
    )
  )
}

predicate isStmtNode2(ControlFlowNode cfn1) {
  exists(ExprStmt stmt1 | isStmt2(stmt1) and cfn1 = stmt1)
}

from ControlFlowNode cfn
where
  isStmtNode2(cfn) and
  not exists(ControlFlowNode cfn1 |
    isStmtNode1(cfn1) and
    cfn1.getASuccessor+() = cfn
  )
select cfn, "Match DSL"