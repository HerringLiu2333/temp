import cpp
import semmle.code.cpp.controlflow.ControlFlowGraph

predicate isStmt1(IfStmt ifs1) {
  exists(NotExpr ne1, FunctionCall fc1, EnumConstantAccess ea1 |
    ne1 = ifs1.getCondition().getUnconverted() and
    fc1 = ne1.getOperand().getUnconverted() and
    fc1.getTarget().hasName("CurrentlyOn") and
    ea1 = fc1.getArgument(0).getUnconverted() and
    ea1.getTarget().hasName("IO")
  )
}

predicate isStmtNode1(ControlFlowNode cfn1) {
  exists(IfStmt stmt1 | isStmt1(stmt1) and cfn1 = stmt1)
}

predicate isStmt2(DeclStmt ds1, Variable v1, Variable v2) {
  exists(LocalVariable lv1, FunctionCall fc1, FieldAccess fa1, VariableAccess va1 |
    ds1.getADeclaration() = lv1 and
    lv1 = v2 and
    fc1 = lv1.getInitializer().getExpr().getUnconverted() and
    fc1.getTarget().hasName("LookupControllerBySessionId") and
    fa1 = fc1.getArgument(0).getUnconverted() and
    fa1.getTarget().hasName("first") and
    va1 = fa1.getQualifier().getUnconverted() and
    va1.getTarget() = v1
  )
}

predicate isStmtNode2(ControlFlowNode cfn1, Variable v1, Variable v2) {
  exists(DeclStmt stmt1 | isStmt2(stmt1, v1, v2) and cfn1 = stmt1)
}

predicate isStmt3(ExprStmt es1) {
  exists(FunctionCall fc1 |
    fc1 = es1.getExpr().getUnconverted() and
    fc1.getTarget().hasName("PauseClientBySessionId")
  )
}

predicate isStmtNode3(ControlFlowNode cfn1) {
  exists(ExprStmt stmt1 | isStmt3(stmt1) and cfn1 = stmt1)
}

from ControlFlowNode cfn, Variable v1, Variable v2
where
  isStmtNode3(cfn) and
  exists(ControlFlowNode cfn2 |
    isStmtNode2(cfn2, v1, v2) and
    cfn2.getASuccessor+() = cfn and
    not exists(ControlFlowNode cfn1 |
      isStmtNode1(cfn1) and
      cfn1.getASuccessor+() = cfn2
    )
  ) and
  v1.getType().toString() = "const value_type &" and
  v2.getType().toString() = "VideoCaptureController *"
select cfn, "Match DSL"